typedef double (*sigmoid_t)(double);
double evaluate(sigmoid_t sigmoid) {
double t1 = 1.000000;
double t3 = 2.000000;
double t5 = 3.000000;
double t4 = t3 * t5;
double t2 = t1 + t4;
double t7 = 4.000000;
double t6 = t2 - t7;
return sigmoid(t6);
}
